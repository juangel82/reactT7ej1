/* components/LogoutButton.component.jsx */

export default function LogoutButton(props) {
    return (
        <button onClick={props.onClick}>Desconectarse</button>
    );
}